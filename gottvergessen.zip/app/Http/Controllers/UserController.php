<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    private function UInt32($num)
    {
        return $num & 0xFFFFFFFF;
    }

    private function Int32($num)
    {
        $n = $num & 0xFFFFFFFF;
        return 0 != ($n & 0x80000000) ? $n - 0x100000000 : $n;
    }

    private function tolower($c)
    {
        return ($c >= ord('A') and $c <= ord('Z')) ? $c + (ord('a') - ord('A')) : $c;
    }

    private function joaat($name)
    {
        $hash = 0;
        foreach(str_split($name) as $letter)
        {
            $hash += $this->tolower(ord($letter));
            $hash = $this->UInt32($hash);
            $hash += $hash << 10;
            $hash ^= $this->UInt32($hash) >> 6;
        }

        $hash += $hash << 3;
        $hash ^= $this->UInt32($hash) >> 11;
        $hash += $hash << 15;
        $hash = $this->UInt32($hash);

        return $hash;
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        
        $credentials = $request->only(['username', 'password']);
        
        try
        {
            if (Auth::attempt($credentials, $request->remember)) 
            {
                $request->session()->regenerate();
                return response()->json([
                    "session" => $this->joaat("auth success" . auth()->user()->fullname),
                    "fullname" => auth()->user()->fullname,
                    "ownership" => auth()->user()->ownership,
                    "expired_date" => auth()->user()->expired
                ], 200);
            }
            else
            {
                return response()->json(["status" => $this->joaat("auth failed")], 401);
            }
        }
        catch (\Throwable $th) 
        {
            return response()->json(["status" => $this->joaat("auth failed")], 401);
        }
    }
}
