<div class="col-lg-8 mx-auto my-4">
    <div class="card">
        <div class="card-body">
            <div class="card-title">Update User Information</div>
            <hr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->id == request()->uid): ?>
                    <form action="/dashboard/users/edit_status" method="post">
                        <?php if($user->status === 'pending'): ?>
                            <button class="btn btn-outline-primary waves-effect waves-light" type="submit" name="active">Verified User</button>
                        <?php else: ?>
                            <button class="btn btn-outline-danger waves-effect waves-light" type="submit" name="pending">Unverified User</button>
                        <?php endif; ?>
                    </form>

                    <form action="/dashboard/users/update/<?php echo e(request()->uid); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <?php if(isset($user->image)): ?>
                            <img src="<?php echo e(asset('storage/uploads/avatar') . '/' . $user->image); ?>" class="rounded-circle img-fluid img-thumbnail mx-auto d-block" id="profile-img" alt="profile-img">
                            <?php else: ?>
                            <img src="https://via.placeholder.com/400x400" class="rounded-circle img-fluid img-thumbnail mx-auto my-5 d-block" id="profile-img" alt="">
                            <?php endif; ?>
                            <div class="form-group btn btn-light btn-round px-5 mx-auto d-block">
                                <label for="avatar">Avatar</label>
                                <input type="file" class="form-control" name="image">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fullname">Fullname</label>
                            <input type="text" name="fullname" class="form-control form-control-rounded" id="fullname" placeholder="<?php echo e($user->fullname); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" class="form-control form-control-rounded" id="email" placeholder="<?php echo e($user->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" class="form-control form-control-rounded" id="username" placeholder="<?php echo e($user->username); ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control form-control-rounded" id="password" placeholder="Enter Password" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-light btn-round px-5 mx-auto d-block"><i class="icon-lock"></i>Update Account</button>
                        </div>
                    </form>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH H:\SSD\dbase\Coding\Laravel Project\gottvergessen\resources\views/dashboard/users/edit.blade.php ENDPATH**/ ?>