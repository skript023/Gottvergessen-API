
<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Users List</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Fullname</th>
                        <th scope="col">Ownership</th>
                        <th scope="col">Role</th>
                        <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($user->fullname); ?></td>
                                <?php switch($user->ownership):
                                    case (0): ?>
                                        <td><?php echo e("NOT OWNED"); ?></td>
                                        <?php break; ?>
                                    <?php case (1): ?>
                                        <td><?php echo e("STANDARD EDITION"); ?></td>
                                        <?php break; ?>
                                    <?php case (2): ?>
                                        <td><?php echo e("SILVER EDITION"); ?></td>
                                        <?php break; ?>
                                    <?php case (3): ?>
                                        <td><?php echo e("GOLD EDITION"); ?></td>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <td><?php echo e("DEVELOPER VERSION"); ?></td>
                                        <?php break; ?>
                                <?php endswitch; ?>
                                <td><?php echo e($user->role); ?></td>
                                <td><?php echo e($user->status); ?></td>
                                <td>
                                <div class="btn-group">
                                <button type="button" class="btn btn-light btn-block waves-effect waves-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li class="dropdown-divider"></li>
                                    <a href="users?delete=<<?php echo e($user->id); ?>"><li class="dropdown-item">Delete User</li></a>
                                    <li class="dropdown-divider"></li>
                                    <a href="users?page=edit&uid=<?php echo e($user->id); ?>"><li class="dropdown-item">Edit User</li></a>
                                    <li class="dropdown-divider"></li>
                                    
                                </ul>
                            </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\SSD\dbase\Coding\Laravel Project\gottvergessen\resources\views/dashboard/users/view.blade.php ENDPATH**/ ?>