<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>



<h1 align="center">Gottvergessen REST API</h1>
<p align="center">
  <a href="https://github.com/skript023/Gottvergessen-API/blob/main/LICENSE">
    <img src="https://img.shields.io/github/license/skript023/Gottvergessen-API.svg?style=flat-square"/>
   </a>
  <a href="https://github.com/skript023/Gottvergessen-API/actions">
      <img src="https://github.com/skript023/Gottvergessen-Loader/actions/workflows/main.yml/badge.svg"/>
   </a>
  <br>
  A simple DLL API handlig for <a href="https://github.com/skript023/Gottvergessen-Loader">Gottvergessen Loader</a>
  Strictly for educational purposes.
</p>


## Features

* Laravel based framework

* Login Systems

* Sanctum auth and API token
* Binary send request to C++