<?php

return [
    'public_html' => env('PUBLIC_HTML', false),
];
