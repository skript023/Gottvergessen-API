<!-- Modal -->
<div class="modal fade" id="confirmation-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" id="exampleModalLongTitle"><?php echo $__env->yieldContent('modal-header'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body pt-5">
            <p class="text-dark">
                <?php echo $__env->yieldContent('modal-message'); ?>
            </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <?php echo $__env->yieldContent('action'); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/components/modal-popup.blade.php ENDPATH**/ ?>