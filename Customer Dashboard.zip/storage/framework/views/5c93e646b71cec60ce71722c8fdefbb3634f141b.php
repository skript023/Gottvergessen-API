<div class="col-lg-8 mx-auto my-4">
    <div class="card">
        <div class="card-body">
            <div class="card-title">Update Transaction History</div>
            <hr>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($transaction->id == request()->transaction): ?>
                    <form action="/dashboard/transaction/update/<?php echo e($transaction->id); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="input-6">Type</label>
                        <select id="type" name="type" class="form-control text-center mb-3">
                            <option class="bg-dark-light" value="">--- Select type ---</option>
                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="bg-dark-light" value="<?php echo e($wallet->symbol); ?>"><?php echo e($wallet->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control form-control-rounded" id="title" placeholder="<?php echo e($transaction->title); ?>">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" name="description" class="form-control form-control-rounded" id="description" placeholder="<?php echo e($transaction->description); ?>">
                        </div>
                        <div class="form-group">
                            <label for="income">Income</label>
                            <input type="text" name="income" class="form-control form-control-rounded" id="income" placeholder="<?php echo e($transaction->income); ?>">
                        </div>
                        <div class="form-group">
                            <label for="expenditure">Expenditure</label>
                            <input type="text" name="expenditure" class="form-control form-control-rounded" id="expenditure" placeholder="<?php echo e($transaction->expenditure); ?>">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-light btn-round px-5 mx-auto d-block"><i class="icon-lock"></i>Update Account</button>
                        </div>
                    </form>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/transactions/edit.blade.php ENDPATH**/ ?>