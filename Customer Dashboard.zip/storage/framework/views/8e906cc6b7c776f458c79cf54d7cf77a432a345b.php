<div class="alert bg-success-light1" role="alert" id="success-alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <h4 class="alert-heading"><?php echo e(session()->get('header')); ?></h4>
    <hr>
    <p class="mb-0">
        aaasas
    </p>
</div>
  
<script>
    $(document).ready(function() {
        window.setTimeout(function() {
            $(".alert").fadeTo(500, 0).slideUp(500, function(){
                $(this).remove();
            });
        }, 4000);
    });    
</script><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/components/alert-popups-success.blade.php ENDPATH**/ ?>