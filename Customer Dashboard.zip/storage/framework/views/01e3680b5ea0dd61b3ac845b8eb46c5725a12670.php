<div aria-live="polite" aria-atomic="true" style="position: relative; min-height: 200px;">
    <!-- Position it -->
    <div style="position: absolute; top: 0; right: 0;">
  
      <!-- Then put toasts within -->
        <?php echo $__env->make('components.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/components/toast-core.blade.php ENDPATH**/ ?>