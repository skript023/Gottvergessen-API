<form action="/dashboard/ownerships/edit/<?php echo e(request()->edit); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Update Ownerships</label>
        <?php $__currentLoopData = $ownerships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ownership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($ownership->id == request()->edit): ?>
                <input type="text" class="form-control text-center" name="ownership" value="<?php echo e($ownership->ownership); ?>">
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="form-group">
        <button type="submit" name="update" class="btn btn-light btn-block">Update Ownership</button>
    </div>
</form><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/dashboard/ownerships/edit.blade.php ENDPATH**/ ?>