<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
        <div class="brand-logo">
        <a href="/dashboard/profile">
        <img src="<?php echo e(asset('assets')); ?>/images/logo-icon.png" class="logo-icon" alt="logo icon">
        <h5 class="logo-text">Dashboard</h5>
        </a>
    </div>
    <ul class="sidebar-menu do-nicescrol">
        <li class="sidebar-header">MAIN NAVIGATION</li>
        <?php if(auth()->user()->roles->role === 'admin'): ?>
            <li>
                <a href="/dashboard">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="/dashboard/users">
                <i class="zmdi zmdi-accounts-list"></i> <span>Users</span>
                </a>
            </li>
            <li>
                <a href="/dashboard/logging">
                <i class="zmdi zmdi-alert-triangle"></i> <span>Logging</span>
                </a>
            </li>
            <li>
                <a href="/dashboard/role">
                <i class="zmdi zmdi-account-circle"></i> <span>Role</span>
                </a>
            </li>
            <li>
                <a href="/dashboard/bin">
                <i class="zmdi zmdi-folder-star"></i> <span>Binary</span>
                </a>
            </li>
            <li>
                <a href="/dashboard/ownership">
                <i class="zmdi zmdi-chart"></i> <span>Ownerships</span>
                </a>
            </li>
        <?php endif; ?>

        <li>
            <a href="/dashboard/profile">
            <i class="zmdi zmdi-face"></i> <span>Profile</span>
            </a>
        </li>

        <li class="sidebar-header">LABELS</li>
        <li><a href="javaScript:void();"><i class="zmdi zmdi-coffee text-danger"></i> <span>Important</span></a></li>
        <li><a href="javaScript:void();"><i class="zmdi zmdi-chart-donut text-success"></i> <span>Warning</span></a></li>
        <li><a href="javaScript:void();"><i class="zmdi zmdi-share text-info"></i> <span>Information</span></a></li>

        </ul>
    
    </div><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/dashboard/includes/sidebar.blade.php ENDPATH**/ ?>