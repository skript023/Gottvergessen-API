
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('modal-header', 'Log Deletion'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this log? the data will not be able to restored after deletion'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.modal-popup', [
    'data' => $logs, 
    'url' => '/dashboard/logs/delete/',
    'tag' => 'log-delete-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title text-center">Client Log History</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Log Level</th>
                        <th scope="col">Username</th>
                        <th scope="col">File</th>
                        <th scope="col">Line</th>
                        <th scope="col">Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($log->prefix); ?></td>
                                <td><?php echo e($log->owner); ?></td>
                                <td><?php echo e($log->file); ?></td>
                                <td><?php echo e($log->line); ?></td>
                                <td><?php echo e($log->message); ?></td>
                                <td>
                                    <button type="button" data-toggle="modal" data-target="#log-delete-<?php echo e($log->id); ?>" class="btn btn-light">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/logger.blade.php ENDPATH**/ ?>