
<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('modal-header', 'User Deletion'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this user? the data will not be able to restored after deletion'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.modal-popup', [
    'data' => $users, 
    'url' => 'users/suspend/',
    'tag' => 'user-suspend-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.modal-popup', [
    'data' => $users, 
    'url' => 'users/delete/',
    'tag' => 'user-delete-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <div class="my-4">
        <a class="btn btn-light zmdi zmdi-account-add" href="users?page=add"> Add Account</a>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title text-center">Users List</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Fullname</th>
                        <th scope="col">Ownership</th>
                        <th scope="col">Computer</th>
                        <th scope="col">Role</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($user->fullname); ?></td>
                                <td><?php echo e($user->ownerships->type); ?></td>
                                <td><?php echo e($user->computer_name); ?></td>
                                <td><?php echo e($user->roles->role); ?></td>
                                <td><?php echo e($user->activity); ?></td>
                                <td>
                                <div class="btn-group">
                                <button type="button" class="btn btn-light btn-block waves-effect waves-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right bg-dark-light">
                                    <li class="dropdown-divider"></li>
                                    <a href="users?page=edit&user=<?php echo e($user->id); ?>"><li class="dropdown-item">Edit User</li></a>
                                    <li class="dropdown-divider"></li>
                                    <a data-toggle="modal" data-target="#user-delete-<?php echo e($user->id); ?>"><li class="dropdown-item">Delete User</li></a>
                                    <li class="dropdown-divider"></li>
                                    <a data-toggle="modal" data-target="#user-suspend-<?php echo e($user->id); ?>"><li class="dropdown-item">Suspend User</li></a>
                                </ul>
                            </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/users/view.blade.php ENDPATH**/ ?>