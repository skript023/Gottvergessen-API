
<?php $__env->startSection('modal-header', 'Are you sure want to delete the ownership?'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this ownership? the data will not be able to restored after deletion'); ?>
<?php $__env->startSection('title', 'Ownerships Information'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.modal-popup', [
    'data' => $ownerships, 
    'url' => '/dashboard/ownership/delete/',
    'tag' => 'product-delete-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="card col-md-4 mx-auto my-4">
            <div class="card-content p-2">
                <div class="card-body">
                    <div class="card-title text-uppercase text-center py-3">Add Product</div>
                    <form action="/dashboard/role/add" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="input-6" class="text-center">Products</label>
                            <input type="text" name="role" class="form-control form-control-rounded text-center" id="input-6" placeholder="Enter Product Name" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-light btn-round px-5 mx-auto d-block"><i class="icon-lock"></i> Add Product</button>
                        </div>
                    </form>
                    <?php if(isset(request()->edit)): ?>
                        <?php echo $__env->make('dashboard.ownerships.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card col-md-6 mx-auto my-4">
            <div class="card-content p-2">
                <div class="card-body">
                    <div class="card-title text-uppercase text-center py-3">Existed Products</div>
                    <table class="table table-boardered">
                        <thead>
                        <tr>
                       <th>Products</th>
                       <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ownerships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ownership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ownership->type); ?></td>
                                <td>
                                    <a href="/dashboard/ownership?edit=<?php echo e($ownership->id); ?>" class="btn btn-light">Update</a>
                                    <button type="button" data-toggle="modal" data-target="#product-delete-<?php echo e($ownership->id); ?>" class="btn btn-light">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/ownerships.blade.php ENDPATH**/ ?>