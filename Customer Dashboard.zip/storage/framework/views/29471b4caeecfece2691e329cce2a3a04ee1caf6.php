
<?php $__env->startSection('title', 'Role Information'); ?>
<?php $__env->startSection('modal-header', 'Role Deletion'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this role? the data will not be able to restored after deletion'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="card col-md-4 mx-auto my-4">
            <div class="card-content p-2">
                <div class="card-body">
                    <div class="card-title text-uppercase text-center py-3">Add Role</div>
                    <form action="/dashboard/role/add" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="input-6" class="text-center">Role</label>
                            <input type="text" name="role" class="form-control form-control-rounded text-center" id="input-6" placeholder="Enter Role Name" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-light btn-round px-5 mx-auto d-block"><i class="icon-lock"></i> Add Role</button>
                        </div>
                    </form>
                    <?php if(isset(request()->edit)): ?>
                        <?php echo $__env->make('dashboard.roles.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card col-md-6 mx-auto my-4">
            <div class="card-content p-2">
                <div class="card-body">
                    <div class="card-title text-uppercase text-center py-3">List Role</div>
                    <table class="table table-boardered">
                        <thead>
                        <tr>
                       <th>Role Name</th>
                       <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->role); ?></td>
                                <td>
                                    <a href="/dashboard/role?edit=<?php echo e($role->id); ?>" class="btn btn-light">Update</a>
                                    <button type="button" data-toggle="modal" data-target="#confirmation-modal" class="btn btn-light">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
    <a href="/dashboard/role/delete/<?php echo e($role->id); ?>" type="button" class="btn btn-success">Ok</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/dashboard/role.blade.php ENDPATH**/ ?>