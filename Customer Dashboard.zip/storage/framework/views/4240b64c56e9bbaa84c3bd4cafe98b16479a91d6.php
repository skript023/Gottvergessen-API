
<?php $__env->startSection('title', 'Binaries Management'); ?>
<?php $__env->startSection('modal-header', 'Binary Deletion'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this binary? the data will not be able to restored after deletion'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.modal-popup', [
    'data' => $binaries, 
    'url' => 'bin/delete/',
    'tag' => 'binary-delete-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <div class="my-4">
        <a class="btn btn-light zmdi zmdi-collection-plus" href="/dashboard/bin?page=add"> Add Binary</a>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title text-center">Existed Binaries in Server</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Game</th>
                        <th scope="col">Bin</th>
                        <th scope="col">Target</th>
                        <th scope="col">Version</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $binaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($bin->game); ?></td>
                                <td><?php echo e($bin->file); ?></td>
                                <td><?php echo e($bin->target); ?></td>
                                <td><?php echo e($bin->version); ?></td>
                                <td><?php echo e($bin->supported == 1 ? "Supported" : "Abanddoned"); ?></td>
                                <td>
                                <div class="btn-group mx-auto">
                                    <button type="button" class="btn btn-light btn-block waves-effect waves-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Action
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right bg-dark-light">
                                        <li class="dropdown-divider"></li>
                                        <a href="bin?page=upload&bin=<?php echo e($bin->id); ?>"><li class="dropdown-item">Upload</li></a>
                                        <li class="dropdown-divider"></li>
                                        <li class="dropdown-divider"></li>
                                        <a href="bin?page=edit&bin=<?php echo e($bin->id); ?>"><li class="dropdown-item">Edit</li></a>
                                        <li class="dropdown-divider"></li>
                                        <a data-toggle="modal" data-target="#binary-delete-<?php echo e($bin->id); ?>"><li class="dropdown-item">Delete</li></a>
                                    </ul>
                                </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/bin/view.blade.php ENDPATH**/ ?>