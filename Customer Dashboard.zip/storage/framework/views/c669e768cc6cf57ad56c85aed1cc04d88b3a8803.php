
<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('modal-header', 'Transaction Deletion'); ?>
<?php $__env->startSection('modal-message', 'Are you sure want to delete this tranaction? the data will not be able to restored after deletion'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.modal-popup', [
    'data' => $transactions, 
    'url' => 'transaction/delete/',
    'tag' => 'transaction-delete-'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-lg-12">
    <div class="my-4">
        <a class="btn btn-light zmdi zmdi-account-add" href="transaction-history?page=add"> Add Transaction</a>
    </div>
    <div class="card mt-3 col-xl-4">
        <div class="card-content">
            <div class="row row-group m-0">
                <div class="card-body">
                    <p class="mb-3 text-white small-font">Total Revenue</p>
                    <h5 class="text-white mb-0"><?php echo e($total_income); ?> <span class="float-right"><i class="fa fa-bar-chart"></i></span></h5>
                    <div class="progress my-3" style="height:3px;">
                    <div class="progress-bar" style="width:55%"></div>
                    </div>
                    <p class="mb-0 text-white small-font">Rate Revenue <span class="float-right"><?php echo e($avg_inc > 0 ? "+" : "-"); ?><?php echo e($avg_inc); ?>% <i class="<?php echo e($avg_inc > 0 ? "zmdi zmdi-long-arrow-up"  : "zmdi zmdi-long-arrow-down"); ?>"></i></span></p>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-3">
        <div class="card-content">
            <div class="row row-group m-0">
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Total Expenditure</p>
                        <h5 class="text-white mb-0"><?php echo e(abs($total_expenditure)); ?> <span class="float-right"><i class="fa fa-shopping-cart"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                        <div class="progress-bar" style="width:<?php echo e($total_rate_expenditure); ?>%"></div>
                    </div>
                    <p class="mb-0 text-white small-font">Rate Expenditure <span class="float-right"><?php echo e($total_rate_expenditure > 0 ? "+" : "-"); ?><?php echo e($total_rate_expenditure); ?>% <i class="<?php echo e($total_rate_expenditure > 0 ? "zmdi zmdi-long-arrow-up"  : "zmdi zmdi-long-arrow-down"); ?>"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">E-Money Expenditure</p>
                        <h5 class="text-white mb-0"><?php echo e(abs($transactions->where('type', 'e-money')->sum('expenditure'))); ?> <span class="float-right"><i class="fa fa-bar-chart"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                        <div class="progress-bar" style="width:<?php echo e($emoney_expenditure); ?>%"></div>
                    </div>
                    <p class="mb-0 text-white small-font">E-Money Expenditure<span class="float-right"><?php echo e($emoney_expenditure > 0 ? "+" : "-"); ?><?php echo e($emoney_expenditure); ?>% <i class="<?php echo e($emoney_expenditure > 0 ? "zmdi zmdi-long-arrow-up"  : "zmdi zmdi-long-arrow-down"); ?>"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Bank Expenditure</p>
                        <h5 class="text-white mb-0"><?php echo e(abs($transactions->where('type', 'bank')->sum('expenditure'))); ?> <span class="float-right"><i class="fa fa-cc-visa"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                            <div class="progress-bar" style="width:<?php echo e($rate_bank_expenditure); ?>%"></div>
                        </div>
                        <p class="mb-0 text-white small-font">Bank Expenditure<span class="float-right">+<?php echo e($rate_bank_expenditure); ?>% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Cash Expenditure</p>
                        <h5 class="text-white mb-0"><?php echo e(abs($transactions->where('type', 'cash')->sum('expenditure'))); ?> <span class="float-right"><i class="fa fa-money"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                            <div class="progress-bar" style="width:<?php echo e($rate_cash_expenditure); ?>%"></div>
                        </div>
                        <p class="mb-0 text-white small-font">Cash Expenditure <span class="float-right">+<?php echo e($rate_cash_expenditure); ?>% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-3">
        <div class="card-content">
            <div class="row row-group m-0">
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">E-Money Balance</p>
                        <h5 class="text-white mb-0"><?php echo e($emoney); ?> <span class="float-right"><i class="fa fa-shopping-cart"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                        <div class="progress-bar" style="width:<?php echo e($emoney_usage); ?>%"></div>
                    </div>
                    <p class="mb-0 text-white small-font">E-Money Usage<span class="float-right"><?php echo e($emoney_usage > 0 ? "+" : "-"); ?><?php echo e($emoney_usage); ?>% <i class="<?php echo e($emoney_usage > 0 ? "zmdi zmdi-long-arrow-up"  : "zmdi zmdi-long-arrow-down"); ?>"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Gopay Balance</p>
                        <h5 class="text-white mb-0"><?php echo e($gopay); ?> <span class="float-right"><i class="fa fa-bar-chart"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                        <div class="progress-bar" style="width:<?php echo e($gopay_usage); ?>%"></div>
                    </div>
                    <p class="mb-0 text-white small-font">Gopay Usage<span class="float-right">+<?php echo e($gopay_usage); ?>% <i class="<?php echo e($gopay_usage > 0 ? "zmdi zmdi-long-arrow-up"  : "zmdi zmdi-long-arrow-down"); ?>"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Bank Balance</p>
                        <h5 class="text-white mb-0"><?php echo e($bank); ?> <span class="float-right"><i class="fa fa-cc-visa"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                            <div class="progress-bar" style="width:<?php echo e($bank_usage); ?>%"></div>
                        </div>
                        <p class="mb-0 text-white small-font">Bank Usage<span class="float-right">+<?php echo e($bank_usage); ?>% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6 col-xl-3 border-light">
                    <div class="card-body">
                        <p class="mb-3 text-white small-font">Cash Balance</p>
                        <h5 class="text-white mb-0"><?php echo e($cash); ?> <span class="float-right"><i class="fa fa-money"></i></span></h5>
                        <div class="progress my-3" style="height:3px;">
                            <div class="progress-bar" style="width:<?php echo e($cash_usage); ?>%"></div>
                        </div>
                        <p class="mb-0 text-white small-font">Cash Usage <span class="float-right">+<?php echo e($cash_usage); ?>% <i class="zmdi zmdi-long-arrow-up"></i></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title text-center">Transaction History</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Type</th>
                        <th scope="col">Income</th>
                        <th scope="col">Expenditure</th>
                        <th scope="col">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($transaction->title); ?></td>
                                <td><?php echo e($transaction->description); ?></td>
                                <td><?php echo e($transaction->type); ?></td>
                                <td><?php echo e($transaction->user->balance->wallet->currency); ?> <?php echo e($transaction->income); ?></td>
                                <td><?php echo e($transaction->user->balance->wallet->currency); ?> <?php echo e($transaction->expenditure); ?></td>
                                <td><?php echo e($transaction->transaction_date); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-light btn-block waves-effect waves-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right bg-dark-light">
                                            <li class="dropdown-divider"></li>
                                            <a href="transaction-history?page=edit&transaction=<?php echo e($transaction->id); ?>"><li class="dropdown-item">Edit User</li></a>
                                            <li class="dropdown-divider"></li>
                                            <a data-toggle="modal" data-target="#transaction-delete-<?php echo e($transaction->id); ?>"><li class="dropdown-item">Delete User</li></a>
                                            <li class="dropdown-divider"></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>IDR <?php echo e($total_income); ?></td>
                            <td>IDR <?php echo e($total_expenditure); ?></td>
                        </tr>   
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.core', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Customer Dashboard\resources\views/dashboard/transactions/view.blade.php ENDPATH**/ ?>