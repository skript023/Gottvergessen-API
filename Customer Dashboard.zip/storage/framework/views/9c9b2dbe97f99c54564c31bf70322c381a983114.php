<form action="/dashboard/role/edit/<?php echo e(request()->edit); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Update Role</label>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($role->id == request()->edit): ?>
                <input type="text" class="form-control" name="role_name" value="<?php echo e($role->role); ?>">
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="form-group">
        <button type="submit" name="update" class="btn btn-light btn-block">Update Role</button>
    </div>
</form><?php /**PATH D:\Coding\Gottvergessen-API\resources\views/dashboard/roles/edit.blade.php ENDPATH**/ ?>